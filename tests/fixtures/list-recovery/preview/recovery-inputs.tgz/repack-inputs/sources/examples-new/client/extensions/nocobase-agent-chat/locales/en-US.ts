export interface AgentChatLocale {
  readonly chat: {
    readonly webSearch: {
      readonly title: string;
      readonly queryCount: string;
      readonly expand: string;
      readonly collapse: string;
      readonly toggle: string;
      readonly unsupported: string;
      readonly searching: string;
      readonly completed: string;
      readonly unverified: string;
      readonly unverifiedNotice: string;
      readonly partial: string;
      readonly failed: string;
      readonly cancelled: string;
      readonly interrupted: string;
      readonly timeout: string;
      readonly unavailable: string;
      readonly noEvidence: string;
      readonly sources: string;
    };
    readonly retrySaving: string;
    readonly cancel: string;
    readonly editMessage: string;
    readonly copyMessage: string;
    readonly refreshReply: string;
    readonly copyFailed: string;
    readonly resendConfirm: string;
    readonly resend: {
      readonly rejected: string;
      readonly unknown: string;
      readonly needsSync: string;
    };
    readonly contextFailed: string;
    readonly approval: {
      readonly request: string;
      readonly approve: string;
      readonly deny: string;
      readonly denied: string;
      readonly failed: string;
    };
    readonly feedback: {
      readonly sending: string;
      readonly waiting: string;
      readonly thinking: string;
      readonly stopping: string;
      readonly completed: string;
      readonly cancelled: string;
      readonly failed: string;
      readonly unknown: string;
      readonly effectReview: string;
    };
    readonly connectionUnknown: string;
    readonly historicalReadOnly: string;
    readonly executionFailed: string;
    readonly allowAnother: string;
    readonly creationUnknown: string;
    readonly retryCreation: string;
    readonly refreshHistory: string;
    readonly signIn: string;
    readonly title: string;
    readonly ask: string;
    readonly close: string;
    readonly expand: string;
    readonly restoreSize: string;
    readonly openPage: string;
    readonly openInPanel: string;
    readonly more: string;
    readonly newConversation: string;
    readonly untitled: string;
    readonly rename: string;
    readonly renameHint: string;
    readonly archive: string;
    readonly unarchive: string;
    readonly renamed: string;
    readonly archivedNamed: string;
    readonly unarchived: string;
    readonly undo: string;
    readonly you: string;
    readonly agentGone: string;
    readonly anyAgent: string;
    readonly loadFailed: string;
    readonly notFound: string;
    readonly notFoundDescription: string;
    readonly emptyTitle: string;
    readonly emptyDescription: string;
    readonly noAgent: string;
    readonly chooseAgent: string;
    readonly messages: string;
    readonly olderMessages: string;
    readonly sources: {
      readonly panel: string;
    };
    readonly availability: {
      readonly online: string;
      readonly agentMissing: string;
      readonly agentArchived: string;
      readonly forbidden: string;
      readonly noModel: string;
      readonly noRunner: string;
      readonly othersPersonal: string;
      readonly modelUnavailable: string;
    };
    readonly reasoning: {
      readonly title: string;
      readonly thinking: string;
    };
    readonly reply: {
      readonly writing: string;
      readonly interrupted: string;
    };
    readonly offline: {
      readonly agentMissing: string;
      readonly agentArchived: string;
      readonly forbidden: string;
      readonly noModel: string;
      readonly noRunner: string;
      readonly othersPersonal: string;
      readonly modelUnavailable: string;
      readonly kept: string;
      readonly fallback: string;
      readonly usingDefault: string;
      readonly restore: string;
    };
    readonly fileInputFailures: {
      readonly imageCapability: string;
      readonly unsupportedFormat: string;
      readonly formatMismatch: string;
      readonly invalidInline: string;
      readonly fileTooLarge: string;
      readonly inputTooLarge: string;
      readonly documentTooLarge: string;
      readonly contextTooLarge: string;
      readonly fileCount: string;
      readonly nativeFileCount: string;
      readonly unreadable: string;
      readonly extractionFailed: string;
      readonly extractionTimeout: string;
      readonly preparationFailed: string;
    };
    readonly notice: {
      readonly switchedToDefault: string;
      readonly switchedToOnline: string;
      readonly onlineFallbackUnavailable: string;
      readonly switchedBack: string;
      readonly runFailed: string;
      readonly runFailedReason: string;
      readonly runCancelled: string;
    };
    readonly consultation: {
      readonly title: string;
      readonly question: string;
      readonly answer: string;
      readonly steps: string;
      readonly usage: string;
      readonly state: {
        readonly running: string;
        readonly completed: string;
        readonly failed: string;
        readonly refused: string;
      };
    };
    readonly steps: {
      readonly title: string;
      readonly waiting: string;
      readonly starting: string;
      readonly thinking: string;
      readonly reading: string;
      readonly working: string;
      readonly count_one: string;
      readonly count_other: string;
      readonly started: string;
      readonly finished: string;
    };
    readonly pending: {
      readonly sending: string;
      readonly failed: string;
      readonly retry: string;
      readonly discard: string;
    };
    readonly composer: {
      readonly label: string;
      readonly placeholder: string;
      readonly hint: string;
      readonly runningHint: string;
      readonly tooLong: string;
      readonly send: string;
      readonly stop: string;
      readonly stopping: string;
    };
    readonly attachments: {
      readonly attach: string;
      readonly label: string;
      readonly sent: string;
      readonly images: string;
      readonly files: string;
      readonly remove: string;
      readonly uploading: string;
      readonly tooLarge: string;
      readonly failed: string;
      readonly tooMany: string;
      readonly blocked: string;
      readonly waiting: string;
      readonly drop: string;
      readonly preview: string;
      readonly download: string;
      readonly previous: string;
      readonly next: string;
    };
    readonly context: {
      readonly label: string;
      readonly sent: string;
      readonly filter: string;
      readonly selection: string;
      readonly remove: string;
      readonly inspect: string;
      readonly preview: string;
    };
    readonly modes: {
      readonly online: string;
      readonly runner: string;
      readonly switchToOnline: string;
      readonly switchToRunner: string;
    };
    readonly agents: {
      readonly models: string;
      readonly defaultModel: string;
      readonly runnerAgents: string;
      readonly modelPlaceholder: string;
      readonly modelSwitch: string;
      readonly modelOnlySwitch: string;
      readonly modelLoadFailed: string;
      readonly modelChangeFailed: string;
      readonly modelSearch: string;
      readonly noMatchingModels: string;
      readonly modelHint: string;
      readonly mixedHint: string;
      readonly search: string;
      readonly noResults: string;
      readonly switch: string;
      readonly withStatus: string;
      readonly chooseFor: string;
      readonly startWith: string;
      readonly boundHint: string;
      readonly empty: string;
      readonly none: string;
      readonly field: string;
      readonly unknown: string;
      readonly placeholder: string;
      readonly myDefault: string;
      readonly systemDefault: string;
      readonly personal: string;
      readonly temporary: string;
      readonly hint: string;
    };
    readonly history: {
      readonly title: string;
      readonly search: string;
      readonly show: string;
      readonly active: string;
      readonly archived: string;
      readonly agent: string;
      readonly allAgents: string;
      readonly source: string;
      readonly allSources: string;
      readonly loadFailed: string;
      readonly noMatch: string;
      readonly clearFilters: string;
      readonly noArchived: string;
      readonly empty: string;
      readonly more: string;
      readonly unread: string;
      readonly actions: string;
    };
    readonly loading: string;
    readonly retry: string;
    readonly errors: {
      readonly forbidden: string;
      readonly notFound: string;
      readonly requestFailed: string;
      readonly signInRequired: string;
    };
    readonly transcript: {
      readonly waiting: string;
      readonly empty: string;
      readonly fetchFailed: string;
      readonly expand: string;
      readonly truncated: string;
      readonly events: string;
      readonly inputDelivered: string;
      readonly tokens: string;
      readonly kinds: {
        readonly text: string;
        readonly thinking: string;
        readonly toolUse: string;
        readonly toolResult: string;
        readonly allowed: string;
        readonly denied: string;
        readonly input: string;
        readonly checkout: string;
        readonly status: string;
        readonly error: string;
        readonly usage: string;
      };
    };
  };
}

const agentChatEnUS: AgentChatLocale = {
  chat: {
    webSearch: {
      title: 'Web search',
      queryCount: 'Queries · {{count}}',
      expand: 'Expand',
      collapse: 'Collapse',
      toggle: 'Search the web',
      unsupported: 'Select a supported model to enable web search.',
      searching: 'Searching…',
      completed: 'Sources retrieved',
      unverified: 'Search not verified',
      unverifiedNotice:
        'The provider returned an answer without search evidence. Search execution, freshness and sources could not be verified.',
      partial: 'Some searches failed',
      failed: 'Search unavailable',
      cancelled: 'Search cancelled',
      interrupted: 'Search interrupted',
      timeout: 'Search timed out.',
      unavailable: 'Search is temporarily unavailable.',
      noEvidence: 'No verified web evidence was returned.',
      sources: 'Sources',
    },
    retrySaving: 'Retry saving',
    cancel: 'Cancel',
    editMessage: 'Edit',
    copyMessage: 'Copy',
    refreshReply: 'Regenerate',
    copyFailed: 'Could not copy the message.',
    resendConfirm: 'Resend',
    resend: {
      rejected: 'The message was not resent. Your edit has been kept.',
      unknown:
        'The resend result is unknown. Refresh history and wait before trying again; the message may already have been accepted.',
      needsSync:
        'The message was accepted, but history has not synchronized. Refresh history; do not send it again.',
    },
    contextFailed:
      'Could not read the selected context or send the message. Check the current page and try again.',
    approval: {
      request: 'This tool needs your approval before it runs.',
      approve: 'Approve',
      deny: 'Deny',
      denied: 'Tool execution was denied.',
      failed:
        'Approval was not confirmed. Refresh the saved message before trying again.',
    },
    feedback: {
      sending: 'Sending…',
      waiting: 'Waiting for the agent…',
      thinking: 'Thinking…',
      stopping: 'Stop requested. Waiting for the agent to finish…',
      completed: 'Completed.',
      cancelled:
        'Cancelled. Check possibly completed actions before repeating them.',
      failed:
        'The response failed. Check history before deciding whether to send again.',
      unknown:
        'The result or its saved history is not confirmed. Refresh history before deciding whether to send again.',
      effectReview:
        'Some actions may have completed. Check their results before repeating them.',
    },

    executionFailed:
      'Execution failed. Check saved history and possibly completed actions before repeating them.',
    historicalReadOnly:
      'This historical conversation is read-only. Start a new chat to continue.',
    connectionUnknown:
      'Connection interrupted. The result is unknown. Refresh saved history before deciding to send again.',
    allowAnother: 'Allow another send (may duplicate)',
    creationUnknown:
      'A conversation may have been created, but its ID was not received. Creating another may leave an empty duplicate. No message is resent automatically.',
    retryCreation: 'Create another conversation and send',
    refreshHistory: 'Refresh history',
    signIn: 'Sign in',
    title: 'Agent chat',
    ask: 'Ask agent',
    close: 'Close',
    expand: 'Full width',
    restoreSize: 'Back to side panel',
    openPage: 'Open full screen',
    openInPanel: 'Open in side panel',
    more: 'More',
    newConversation: 'New conversation',
    untitled: 'Untitled conversation',
    rename: 'Rename',
    renameHint: '{{title}} (click to rename)',
    archive: 'Archive',
    unarchive: 'Unarchive',
    renamed: 'Conversation renamed',
    archivedNamed: 'Archived “{{title}}”',
    unarchived: 'Conversation unarchived',
    undo: 'Undo',
    you: 'You',
    agentGone: 'Deleted agent',
    anyAgent: 'Agent',
    loadFailed: 'Could not load the conversation',
    notFound: 'This conversation cannot be opened',
    notFoundDescription:
      'It may have been removed, or it belongs to someone else.',
    emptyTitle: 'What can {{name}} do for you?',
    emptyDescription:
      'Ask anything, or describe the work to organize. What this page shows goes along as context.',
    noAgent:
      'There is no agent you may chat with. Ask an administrator to enable one, or connect a runner.',
    chooseAgent:
      'Choose who to chat with below. To start with an agent every time, set your default in your profile.',
    messages: 'Messages',
    olderMessages: 'Earlier messages',
    sources: {
      panel: 'Chat panel',
    },
    availability: {
      online: 'Online',
      agentMissing: 'Deleted',
      agentArchived: 'Not enabled',
      forbidden: 'Not available to you',
      noModel: 'Configure a chat model first',
      noRunner: 'No runner online, cannot be chosen',
      othersPersonal: "Only others' personal runners have it",
      // The reason earlier versions wrote on a notice that their online fallback could not answer.
      modelUnavailable: 'Model unavailable',
    },
    reasoning: {
      title: 'Reasoning',
      thinking: 'Thinking…',
    },
    reply: {
      writing: 'Writing…',
      interrupted: 'The reply stopped here.',
    },
    offline: {
      agentMissing: '{{name}} no longer exists',
      agentArchived: '{{name}} is not enabled',
      forbidden: 'You may no longer use {{name}}',
      noModel: 'Configure a chat model first',
      noRunner: '{{name}} has no runner online right now',
      othersPersonal:
        "Only others' personal runners have {{name}}; connect a runner of your own",
      modelUnavailable:
        'The model of {{name}} is not available; ask an administrator',
      kept: 'Your messages are kept and answered once it can answer.',
      fallback: 'Use another agent here',
      usingDefault:
        'This conversation temporarily uses {{name}} in place of {{own}}.',
      restore: 'Switch back to {{own}}',
    },
    fileInputFailures: {
      imageCapability:
        'Image input is not configured for this model. Switch to a model with verified image support.',
      unsupportedFormat:
        'Input for this attachment format is not configured for the selected model, and no local text extractor supports it. Use a supported document format or a model with verified file support.',
      formatMismatch:
        'The attachment filename and media type describe different document formats. Check the file format and upload it again.',
      invalidInline:
        'The attached file data is invalid or too large. Upload the file again or use a smaller file.',
      fileTooLarge:
        'An attachment exceeds its byte budget. Use a smaller file.',
      inputTooLarge:
        'The conversation attachments exceed the input byte budget. Use smaller files or start a new conversation.',
      documentTooLarge:
        'The attachment exceeds its extracted text budget. Use a smaller file.',
      contextTooLarge:
        'The conversation attachments exceed the extracted text budget. Use smaller files or start a new conversation.',
      fileCount:
        'The conversation exceeds the 100 file input limit. Start a new conversation.',
      nativeFileCount:
        'The conversation exceeds the configured native file limit. Use fewer attachments or convert them to a supported text document.',
      unreadable:
        'The attachment contains no readable text. Scanned documents require OCR.',
      extractionFailed:
        'The attachment text could not be extracted. Check that the document is readable and upload it again.',
      extractionTimeout:
        'Attachment text extraction timed out. Use a smaller file or try again.',
      preparationFailed:
        'The attachment could not be prepared. Check your access and the file format, then try again.',
    },
    notice: {
      switchedToDefault:
        'Switched to {{name}}, the system default, until {{own}} is back.',
      switchedToOnline:
        '{{own}} has no runner for you now, so {{name}} answers until {{own}} is back.',
      onlineFallbackUnavailable:
        'The online fallback agent cannot answer ({{reason}}). This conversation stays with {{own}} while it waits for a runner.',
      switchedBack: 'Back with {{name}}.',
      runFailed: 'The agent stopped before answering.',
      runFailedReason: 'The agent stopped before answering: {{reason}}',
      runCancelled: 'Cancellation requested.',
    },
    consultation: {
      title: 'Consulted {{name}}',
      question: 'Question',
      answer: 'Answer',
      steps: 'Its steps',
      usage: 'Used {{input}} input and {{output}} output tokens.',
      state: {
        running: 'Answering…',
        completed: 'Answered',
        failed: 'Failed',
        refused: 'Refused',
      },
    },
    steps: {
      title: 'Steps',
      waiting: 'Waiting for a runner to pick this up…',
      starting: 'Starting…',
      thinking: 'Thinking…',
      reading: 'Looking at {{subject}}',
      working: 'Working on {{subject}}',
      count_one: '{{count}} step',
      count_other: '{{count}} steps',
      started: 'The agent is replying.',
      finished: 'The agent finished replying.',
    },
    pending: {
      sending: 'Sending…',
      failed: 'Not sent',
      retry: 'Send again',
      discard: 'Discard',
    },
    composer: {
      label: 'Message to the agent',
      placeholder: 'Ask, or describe the work to organize…',
      hint: 'Enter to send, Shift+Enter for a new line',
      runningHint: 'Working. You can stop this execution.',
      tooLong: 'At most {{max}} characters.',
      send: 'Send',
      stop: 'Stop',
      stopping: 'Stopping…',
    },
    attachments: {
      attach: 'Attach files',
      label: 'Files the next message carries',
      sent: 'Files sent with this message',
      images: 'Images',
      files: 'Files',
      remove: 'Remove {{name}}',
      uploading: 'Uploading…',
      tooLarge: 'Larger than {{max}}',
      failed: 'Could not upload',
      tooMany: 'At most {{max}} files per message.',
      blocked: 'Remove the files that could not be uploaded to send.',
      waiting: 'Sending once the files are uploaded…',
      drop: 'Drop files to attach them',
      preview: 'Preview {{name}}',
      download: 'Download {{name}}',
      previous: 'Previous image',
      next: 'Next image',
    },
    context: {
      label: 'Context the next message carries',
      sent: 'Context this message carried',
      filter: 'Filter: {{filter}}',
      selection: 'Selected text: “{{text}}”',
      remove: 'Remove context: {{label}}',
      inspect: 'Show context: {{label}}',
      preview: 'Context: {{label}}',
    },
    modes: {
      online: 'Online agent',
      runner: 'Runner agents',
      switchToOnline: 'Switch to the online agent',
      switchToRunner: 'Switch to runner agents',
    },
    agents: {
      models: 'Models',
      defaultModel: 'Default model',
      runnerAgents: 'Agents',
      modelPlaceholder: 'Choose a model',
      modelSwitch: 'Model: {{name}} · {{service}}; choose a model or agent',
      modelOnlySwitch: 'Model: {{name}} · {{service}}; choose a model',
      modelLoadFailed: 'Could not load the conversation model',
      modelChangeFailed: 'Could not confirm the model change',
      modelSearch: 'Search models',
      noMatchingModels: 'No matching models',
      modelHint: 'Choose an online model to chat with.',
      mixedHint: 'Choose an online model or an Agent on a runner to chat with.',
      search: 'Search models or agents',
      noResults: 'No matching models or agents',
      switch: 'Agent: {{name}}; choose another',
      withStatus: '{{name}}, {{status}}',
      chooseFor: 'Chat with',
      startWith: 'Start a new conversation with',
      boundHint:
        'A conversation stays with its agent; choosing another starts a new conversation.',
      empty: 'No agent you may chat with',
      none: 'No agent',
      field: 'Agent: {{name}}',
      unknown: 'Unknown agent',
      placeholder: 'Choose an agent',
      myDefault: 'My default',
      systemDefault: 'System default',
      personal: 'Personal runners only',
      temporary: 'Temporary',
      hint: 'Choose an enabled agent. Online Agent answers directly using the configured chat model.',
    },
    history: {
      title: 'Conversations',
      search: 'Search conversations',
      show: 'Show',
      active: 'Open',
      archived: 'Archived',
      agent: 'Agent',
      allAgents: 'All agents',
      source: 'Started from',
      allSources: 'Anywhere',
      loadFailed: 'Could not load conversations',
      noMatch: 'No conversation matches',
      clearFilters: 'Clear filters',
      noArchived: 'No archived conversations',
      empty: 'No conversations',
      more: 'Load more',
      unread: 'New reply',
      actions: 'Actions for {{title}}',
    },
    loading: 'Loading',
    retry: 'Retry',
    errors: {
      forbidden: 'You are not allowed to do this.',
      notFound: 'It no longer exists.',
      requestFailed: 'The request failed. Try again.',
      signInRequired: 'Your session has expired. Sign in to continue.',
    },
    transcript: {
      waiting: 'Waiting for the agent to start…',
      empty: 'This run recorded no events.',
      fetchFailed: 'Unable to fetch new events. Retrying…',
      expand: 'Show all',
      truncated: 'Cut short: the full text was too long to keep.',
      events: 'Run transcript',
      inputDelivered: '{{count}} input(s) delivered to the agent',
      tokens: '{{input}} tokens in, {{output}} out',
      kinds: {
        text: 'Agent',
        thinking: 'Thinking',
        toolUse: 'Tool',
        toolResult: 'Result',
        allowed: 'Allowed',
        denied: 'Denied',
        input: 'Input',
        checkout: 'Checkout',
        status: 'Status',
        error: 'Error',
        usage: 'Usage',
      },
    },
  },
};

export default agentChatEnUS;
